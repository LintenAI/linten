---
name: test-skill-linten
description: A test skill created by Linten automated tests
---

# Test Skill

This is a minimal test skill created for automated testing purposes.

