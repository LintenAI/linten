export const FINDING_PANEL_WIDTH_KEY = "linten.lens.findingPanelWidth";
